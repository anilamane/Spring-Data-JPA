package com.workshop.anilscode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnilscodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnilscodeApplication.class, args);
	}

}
