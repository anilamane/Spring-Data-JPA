package com.workshop.anilscode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnilscodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
